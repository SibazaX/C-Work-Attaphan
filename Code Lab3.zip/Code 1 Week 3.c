#include <stdio.h>

int main(){
    int a = 10 ;
    int b = 20 , c = 30 , d = 40 ; 
    printf( "This is %d + %d = %d\n" ,a,b,a+b ) ;
    for( int i = 0 ; i < d-30 ; i++ ) {
        if( i < 30 ) {
            printf( "Here\n" ) ;
                if(i == 8) {
                    printf( "This is 8.\n" ) ;
                    printf( "ok\n" ) ;
                }
        }
    }
    return 0;
}